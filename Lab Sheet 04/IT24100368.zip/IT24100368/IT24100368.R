setwd("C:\\Users\\IT24100368\\Desktop\\IT24100368")

#Q1
branch_data <-read.csv("Exercise.txt")
head(branch_data)


#Q2
str(branch_data)



#Q3
# Boxplot for sales
boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales")



#Q4
# Five-number summary for Advertising
summary(branch_data$Advertising)

# Calculate IQR for Advertising
IQR(branch_data$Advertising)


# Function to find outliers using IQR
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


#Q5
# Check for outliers in the Years variable
outliers_years <- find_outliers(branch_data$Years)
print(outliers_years)
